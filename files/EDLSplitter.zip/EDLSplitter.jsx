{
	/*
		EDLSplitter.jsx BETA Version 0.5 by Daniel Bachler (daniel.bachler@danyx.com)
		This script is release under a Creative Commons by-sa license (for
		details see http://creativecommons.org/licenses/by-sa/2.0/ )
		
		This script splits a layer at points given in an EDL (Edit Decision List).
		This is useful if you get a movie file that has been edited by someone else
		and you want your layer split at every edit point (i.e. at every cut), e.g. because
		you want to colour correct it. 
		
		To use this script you need a composition in after effects and a selected layer that
		represents the movie you would like to be cut at points given in an EDL. You also need 
		an ASCII EDL file (most EDL files are, but to check see if you can open the EDL file in a 
		text editor and you can read all timecodes etc. If there are many weird symbols it is probably
		not an ASCII EDL, try to get your editor to export an ASCII EDL in that case).
		
		Before you run the script, set the config variables directly below this comment to the required
		values. 
		
		This script has 3 modes of operation. Mode 1: If you set the variable SET_MARKERS to false
		and CUT_AT_MARKERS also to false, then the layer will simply be split at the points given in 
		the EDL file.
		
		Mode 2: If you set SET_MARKERS to true and CUT_AT_MARKERS to false then the script will mark 
		all edits given in the EDL with layer markers. You can then review these points, see if all of 
		them are at the correct places and if really all of them are needed / wanted, remove or add markers 
		as needed, then proceed to mode 3:
		
		Mode 3: If you set SET_MARKERS to false and CUT_AT_MARKERS to true then the script will 
		split the layer at all points indicated by a layer marker (for example by the ones set by this
		script in Mode 2, but the markers can also be set by different means).
		
		Set FPS to the framerate of your movie (usually 25 in PAL/SECAM countries (Europe) and 
		29.97 or 30 or 23.976 for the USA and Japan).
		
		If you have problems with this script or would like to suggest an extension or simply to 
		tell me that you like it, just write me an email at daniel.bachler@danyx.com
	*/

	// EDIT THESE VARIABLES before you run the script!
	var FPS = 25;
	var SET_MARKERS = true;
	var CUT_AT_MARKERS = false;
	
	// Script code starts here	
	function processLayer(time, layer, doSplitLayer, markername)
	{
		// Check if we should split or set markers
		if (doSplitLayer)
		{
			// See if the point is valid
			if (time < layer.outPoint && time > layer.inPoint)
			{
				// we were asked to split, do so now
				var newlayer = layer.duplicate();
				newlayer.inPoint = time;
				layer.outPoint = time;
				layer = newlayer;
				writeLn("layer split at: " + time);
			}
			else
				writeLn("line not split because not within layer in/out. Time: " + time);
		}
		else
		{
			// we should set a new marker
			var marker = new MarkerValue(markername);
			layer.property("Marker").setValueAtTime(time, marker);
			writeLn("line processed, marker set at: " + time);
		}
		return layer;
	}

	function splitEdl()
	{
		// Check some of the usual stuff (app running, composition active, ...)		
		if (app.project == null)
			return;
		
		var comp = app.project.activeItem;
		
		if ((comp == null) || !(comp instanceof CompItem))
		{
			alert("No composition open!");
			return;
		}
		
		if ((comp.selectedLayers.length != 1))
		{
			alert("Make sure that exactly one layer is selected!");
			return;
		}
		
		var layer = comp.selectedLayers[0];
		
		if (layer == null)
		{
			alert("Could not get selected layer");
			return;
		}		
	
		// Check if we should split at existing markers or mark / split from an EDL
		if (CUT_AT_MARKERS)
		{
			try
			{
				// check if there are any markers
				if (layer.property("Marker") == null)
				{
					alert("Could not find any markers at active layer!");
					return;
				}			
				var markers = layer.property("Marker");
				
				var numMarkers = markers.numKeys;
				var splitPoints = new Array();
				
				// go through the markers, store the split points
				var index;
				for (index = 0; index < markers.numKeys; index++)
				{
					splitPoints[index] = markers.keyTime(index+1);
				}
			
				// delete the markers
				while (markers.numKeys > 0)
				{
					markers.removeKey(markers.numKeys);
				}
			
				// split the layer
				for  (index = 0; index < numMarkers; index++)
				{
					layer = processLayer(splitPoints[index], layer, true, "");
				}
			}
			finally
			{
				app.endUndoGroup();
			}
		}
		else
		{
			// ask the user for the edl file
			var edlfile = File.openDialog("Select EDL file to split with");
			
			// check that the file existed, initialize some variables
			if ((edlfile == null) || !edlfile.exists)
				return;
				
			// this regular expression is used to chop up a line in an edl file. If a particular flavour of EDL does not
			// work, try to change this regex
			var regex = /^([0-9]+)\s+([A-Z0-9]+)\s+([A-Z]+)\s+([A-Z]+)\s+([0-9]+)?\s+([0-9]{2}:[0-9]{2}:[0-9]{2}:[0-9]{2})\s+([0-9]{2}:[0-9]{2}:[0-9]{2}:[0-9]{2})\s+([0-9]{2}:[0-9]{2}:[0-9]{2}:[0-9]{2})\s+([0-9]{2}:[0-9]{2}:[0-9]{2}:[0-9]{2})/;

			var ALL = 0;
			var EDITNUMBER = 1;
			var REELNAME = 2;
			var TARGETTRACK = 3;
			var DISSOLVETYPE = 4;
			var DISSOLVEDURATION = 5;
			var INSOURCE = 6;
			var OUTSOURCE = 7;
			var INTIMELINE = 8;
			var OUTTIMELINE = 9;
			
			if (!edlfile.open("r"))
				return;
			
			// go through each line of the edl file
			app.beginUndoGroup("EDLsplit");
			try
			{
				while (!edlfile.eof)
				{
					var line = edlfile.readln();
					if (line != "")
					{
						var results = regex.exec(line);
						// chop up the line with the regex, see if it worked
						if (results != null)
						{
							// if it worked we have all the timecodes etc we need, store these in nice variables now
							var editnumber = results[EDITNUMBER];
							var reelname = results[REELNAME];
							var dissolveduration = "";
							var insource = "";
							var outsource = "";
							var intimeline = "";
							var outtimeline = "";
							
							// if there is a duration, everything is as expected. If there is no duration, all indices are
							// shifted by one
							if (results.length == 10)
							{
								dissolveduration = results[DISSOLVEDURATION];
								insource = results[INSOURCE];
								outsource = results[OUTSOURCE];
								intimeline = results[INTIMELINE];
								outtimeline = results[OUTTIMELINE];
							}
							else	
							{
								insource = results[DISSOLVEDURATION];
								outsource = results[INSOURCE];
								intimeline = results[OUTSOURCE];
								outtimeline = results[INTIMELINE];
							}
						
							// get the time of the cut in AE time (seconds)
							var time = currentFormatToTime(intimeline, FPS, true);
							
							// process the layer (splitting or marking at the edit point)
							layer = processLayer(time, layer, !SET_MARKERS, editnumber + " " + reelname);
							
							// if a dissolve duration was given, split at the end of the duration as well
							if (dissolveduration != null && dissolveduration != "")
							{
								dissolvedurationFrames = parseInt(dissolveduration, 10) ;
								durationInSeconds = dissolvedurationFrames / FPS;
								time = time + durationInSeconds;
								layer = processLayer(time, layer, !SET_MARKERS, editnumber + " " + reelname);
							}
						}
						else
						{
							// write ingored lines here
							writeLn("line ignored: " + line);
						}
					}
				}
			}
			finally
			{
				edlfile.close();
				app.endUndoGroup();
			}
		}
	}
	
	splitEdl();
}
/*
TITLE: testedl

001  AX       V     C        00:00:00:00 00:00:04:13 00:00:00:00 00:00:04:13
REEL AX IS CLIP Kuc original.avi
*/