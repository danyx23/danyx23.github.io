<?php
// $Id: theme-settings.php,v 1.6 2008/05/13 09:19:13 johnalbin Exp $

/**
 * Implementation of THEMEHOOK_settings() function.
 *
 * @param $saved_settings
 *   An array of saved settings for this theme.
 * @return
 *   A form array.
 */
function bambooforest_settings($saved_settings) {

  // Get the default values from the .info file.
  $themes = list_themes();
  $defaults = $themes['bambooforest']->info['settings'];

  // Merge the saved variables and their default values.
  $settings = array_merge($defaults, $saved_settings);

  /*
   * Create the form using Forms API: http://api.drupal.org/api/6
   */
  $form = array();
  // -- Delete this line if you want to use this setting
  $form['bambooforest_rotatepath'] = array(
    '#type'          => 'textfield',
    '#title'         => t('Rotating header sub-url'),
    '#description'   => t('Must be a valid suburl to the directory containing the header images'),
    '#default_value' => $settings['bambooforest_rotatepath'],
    '#maxlength'     => 60,
  );
  $form['bambooforest_rotatedir'] = array(
    '#type'          => 'textfield',
    '#title'         => t('Rotating header system directory'),
    '#description'   => t('Must be a valid subdirectory that contains the header images'),
    '#default_value' => $settings['bambooforest_rotatedir'],
    '#maxlength'     => 80,
  );
  // */

  // Add the base theme's settings.
  include_once './' . drupal_get_path('theme', 'zen') . '/theme-settings.php';
  $form += zen_settings($saved_settings, $defaults);

  // Remove some of the base theme's settings.
  unset($form['themedev']['zen_layout']); // We don't need to select the base stylesheet.

  // Return the form
  return $form;
}
